<script src="js/jquery-2.1.4.min.js"></script>
<script src="js/onLoad.js"></script>